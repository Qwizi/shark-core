from django.apps import AppConfig


class PremiumAccountConfig(AppConfig):
    name = 'premium_account'
